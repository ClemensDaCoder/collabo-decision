package collabodecision.webservice.persistence;

import collabodecision.webservice.persistence.domain.DesignDecisionRating;

public interface DesignDecisionRatingDao {
	void saveOrUpdateDesignDecisionRating(DesignDecisionRating designDecisionRating);
}
