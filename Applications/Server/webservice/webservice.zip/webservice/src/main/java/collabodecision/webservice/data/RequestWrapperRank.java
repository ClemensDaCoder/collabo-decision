package collabodecision.webservice.data;

public class RequestWrapperRank {
	
	private long idAlternative;
	
	private int rank;

	public long getIdAlternative() {
		return idAlternative;
	}

	public void setIdAlternative(long idAlternative) {
		this.idAlternative = idAlternative;
	}

	public int getRank() {
		return rank;
	}

	public void setRank(int rank) {
		this.rank = rank;
	}
}
