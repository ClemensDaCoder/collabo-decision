package collabodecision.webservice.service;

public interface FileService {
	void addFile(long id, String pathToFile);
}
