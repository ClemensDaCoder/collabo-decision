angular.module('collaboApp')
.controller('CommentsController', ['$scope', '$http', function($scope, $http) {
	
}]);